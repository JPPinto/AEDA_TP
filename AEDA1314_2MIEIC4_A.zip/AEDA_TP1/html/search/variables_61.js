var searchData=
[
  ['aluno',['aluno',['../class_alunos_por_turma_excedido.html#ad3b26da7b4a81b52cd2e1cf969cbae2e',1,'AlunosPorTurmaExcedido::aluno()'],['../class_aluno_nao_existente.html#a094d853c6593f3b82363171adbcd2158',1,'AlunoNaoExistente::aluno()']]]
];
