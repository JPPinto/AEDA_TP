var searchData=
[
  ['removealuno',['removeAluno',['../class_escola.html#acfa55addf5866a486acdfdc84ee9c66a',1,'Escola']]],
  ['removedisciplina',['removeDisciplina',['../class_escola.html#a2e726efed10bae8f782f2f5370ec9f44',1,'Escola']]],
  ['removeprofessor',['removeProfessor',['../class_escola.html#ab88ff73f646f14380fdbb5a55bc49882',1,'Escola']]],
  ['removeturma',['removeTurma',['../class_escola.html#a4011a23d4f49827e7cc74ea5739e9033',1,'Escola::removeTurma()'],['../class_professor.html#a1cc34746e255348252f50e0b6ab34e41',1,'Professor::removeTurma()']]],
  ['removeturmaresponsavel',['removeTurmaResponsavel',['../class_director_turma.html#a08f76bfffd82b428bd601773fe44a26e',1,'DirectorTurma']]]
];
