var searchData=
[
  ['aluno',['aluno',['../class_alunos_por_turma_excedido.html#ad3b26da7b4a81b52cd2e1cf969cbae2e',1,'AlunosPorTurmaExcedido']]]
];
