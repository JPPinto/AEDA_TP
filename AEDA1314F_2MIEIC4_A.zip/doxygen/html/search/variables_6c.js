var searchData=
[
  ['livraria',['livraria',['../class_livraria_nao_existente.html#a021c64cdcdd66bafe0c3194b4d5d1d2b',1,'LivrariaNaoExistente']]]
];
