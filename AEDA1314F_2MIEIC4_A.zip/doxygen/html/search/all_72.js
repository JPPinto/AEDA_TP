var searchData=
[
  ['removealuno',['removeAluno',['../class_escola.html#a59260e705245fac2405df3db93eadd9f',1,'Escola']]],
  ['removedisciplina',['removeDisciplina',['../class_escola.html#a10746519657ced491e47022dcb5a1512',1,'Escola']]],
  ['removelivraria',['removeLivraria',['../class_escola.html#a435a176cdc995e4f13606569f13dce31',1,'Escola']]],
  ['removeprofessor',['removeProfessor',['../class_escola.html#a6bb79d21f36aaf0a2d2364953fe64af9',1,'Escola']]],
  ['removerexprofessor',['removerExProfessor',['../class_escola.html#a41d7151626cd7b2c1c67f6a5ecdeeb56',1,'Escola']]],
  ['removeturma',['removeTurma',['../class_escola.html#a660276ec60daa3b5ee82b74c90b69e4f',1,'Escola::removeTurma()'],['../class_professor.html#a1cc34746e255348252f50e0b6ab34e41',1,'Professor::removeTurma()']]],
  ['removeturmaresponsavel',['removeTurmaResponsavel',['../class_director_turma.html#a08f76bfffd82b428bd601773fe44a26e',1,'DirectorTurma']]]
];
