var searchData=
[
  ['minlivraria',['minLivraria',['../struct_livraria_1_1min_livraria.html',1,'Livraria']]]
];
