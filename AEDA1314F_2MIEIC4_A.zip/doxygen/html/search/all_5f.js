var searchData=
[
  ['_5fd_5farea',['_d_area',['../class_professor.html#a8d4f3bf2dd857d5cdacc4cb229982a34',1,'Professor']]],
  ['_5fdisciplina',['_disciplina',['../class_professor.html#afca4e4fdf336bcab9b9a94b032175999',1,'Professor']]],
  ['_5fturmas',['_turmas',['../class_professor.html#af407ab1e7b5da16bdb0f70458e5457fa',1,'Professor']]]
];
