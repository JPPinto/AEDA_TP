var searchData=
[
  ['livraria',['Livraria',['../class_livraria.html',1,'Livraria'],['../class_livraria_nao_existente.html#a021c64cdcdd66bafe0c3194b4d5d1d2b',1,'LivrariaNaoExistente::livraria()']]],
  ['livrarianaoexistente',['LivrariaNaoExistente',['../class_livraria_nao_existente.html',1,'']]]
];
