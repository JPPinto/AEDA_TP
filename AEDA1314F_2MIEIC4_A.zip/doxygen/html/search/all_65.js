var searchData=
[
  ['emptydisciplinas',['emptyDisciplinas',['../class_escola.html#adf209680355964e892b88cb0ee756061',1,'Escola']]],
  ['emptyturmas',['emptyTurmas',['../class_escola.html#af341c4902c65df8265371cb463a8cb5d',1,'Escola']]],
  ['escola',['Escola',['../class_escola.html',1,'']]]
];
