var searchData=
[
  ['contactooutofbounds',['ContactoOutOfBounds',['../class_contacto_out_of_bounds.html',1,'']]]
];
