var searchData=
[
  ['criar',['criar',['../class_u_i.html#a586183dc7d09d33dafbfe8ce7f3b6871',1,'UI']]]
];
