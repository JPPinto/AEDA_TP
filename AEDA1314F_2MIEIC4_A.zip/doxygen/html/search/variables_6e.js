var searchData=
[
  ['nome',['nome',['../class_aluno_nao_existente.html#a799da2492f008a33bfbbbdd8292b8aa2',1,'AlunoNaoExistente::nome()'],['../class_professor_nao_existente.html#a41cfad953745ec76c49362bd2ef4a6d3',1,'ProfessorNaoExistente::nome()']]]
];
